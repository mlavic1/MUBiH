$(document).ready(function(){
   $('#sadrzaj').load('pokusaj.php'); 
});