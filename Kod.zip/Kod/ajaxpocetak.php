<!DOCTYPE HTML PUBLIC >
<HTML>
<HEAD>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<TITLE>
Početna
</TITLE>
<link rel="stylesheet" type="text/css" href="pocetna.css">
<link rel="stylesheet" type="text/css" href="login.css">
<script src="login.js"></script>
</HEAD>
<BODY>
<div class="red">
	<div id="slika-logo" class="kol-2 logo"><img src="Logo-Manutd.jpg" alt ="Slika loga"></div>
	<div class="kol-10 meni">
	<ul id="nav">
	<li id="trenutni1"><a href="pocetna">Početna</a></li>
	<li><a href="historijaKluba">Historija kluba</a></li>
	<li><a href="kontakt">Kontakt</a></li>
	<li><a href="clanovi">Članovi</a></li>
	<li><a href="oNama">O nama</a></li>
	<li><a href="login">Login</a></li>
	</ul>
	 </div>
	 <!--<div class="kol-10 stadion"><img src="stadion.jpg" alt ="Slika stadiona"></div>-->	 
</div>

<div class="red " id="sadrzaj"></div>
<script src="jquery-3.1.1.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script src="ajax.js"></script>

</BODY>
</HTML>