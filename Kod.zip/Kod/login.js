function ValidirajUsername(user) {
	var regexName = /^[A-Za-z]{6,10}$/; 

   var form=document.getElementById('loginforma');

   if(!regexName.test(user.value)){
   	user.style.borderColor  = "red";
   	var gres =document.getElementById('greska');
   	gres.innerHTML="Username mora biti slovo i mora imati između 6 i 10 znakova!";

   	var d =document.getElementById('dugme');
   	d.style.visibility = "hidden";

   	
   }
   else{
     user.style.borderColor  = "green"; 
     var gres =document.getElementById('greska');
   	gres.innerHTML="";

   	var d =document.getElementById('dugme');
   	d.style.visibility = "visible";

}

}

function ValidirajPassword(pass){
/*if(pass.value =="")
{
var gres = document.getElementById('greska');
gres.innerHTML="Morate unijeti pasvord";
return false;
}*/
var regexPassword = /^[A-Za-z]{6,10}$/; 

   var form=document.getElementById('loginforma');

   if(!regexPassword.test(pass.value)){
    pass.style.borderColor  = "red";
    var gres =document.getElementById('greska');
    gres.innerHTML="Password mora biti slovo i mora imati između 6 i 10 znakova!";

    var d =document.getElementById('dugme');
    d.style.visibility = "hidden";

    
   }
   else{
     pass.style.borderColor  = "green"; 
     var gres =document.getElementById('greska');
    gres.innerHTML="";

    var d =document.getElementById('dugme');
    d.style.visibility = "visible";

}
}
 
   /* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function funkcijadropdown() {
    document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown menu if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {

    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
} 




