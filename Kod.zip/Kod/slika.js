function funk(img){

var modal = document.getElementById('myModal');


//var img = document.getElementById('slika1');
//var img2 = document.getElementById('slika2');
var modalImg = document.getElementById("img01");
var captionText = document.getElementById("caption");
	
    modal.style.display = "block";
    modalImg.src = img.src;
    captionText.innerHTML = img.alt;
var span = document.getElementsByClassName("close")[0];


span.onclick = function() {
    modal.style.display = "none";
}
    window.onkeydown = function( event ) {
    if ( event.keyCode == 27 ) {
        modal.style.display = "none";
    }
}
}
/*
// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}
<script>
	
// Get the modal
var modal = document.getElementById('myModal');

// Get the image and insert it inside the modal - use its "alt" text as a caption
var img = document.getElementById('slika1');
var modalImg = document.getElementById("img01");
var captionText = document.getElementById("caption");
img.onclick = function funkcija(){
    modal.style.display = "block";
    modalImg.src = this.src;
    captionText.innerHTML = this.alt;
}
var img2 = document.getElementById('slika2');
img2.onclick = function funkcija(){
    modal.style.display = "block";
    modalImg.src = this.src;
    captionText.innerHTML = this.alt;
}
// Get the <span> element that closes the modal

window.onkeydown = function( event ) {
    if ( event.keyCode == 27 ) {
        modal.style.display = "none";
    }
};
</script>
*/